HTTP, CSS and JavaScript project for the Coursera's course "Introduction to Cloud Development with HTML, CSS, JavaScript"
